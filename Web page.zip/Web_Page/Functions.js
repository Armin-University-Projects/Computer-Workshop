function show_info(number)
{
    switch(number)
    {
        case 1:
            document.getElementById("birth_place").innerHTML = "Kerman"
            break;
        case 2:
            document.getElementById("originality").innerHTML = "Dehziar"
            break;
        case 3:
            document.getElementById("hard_skills").innerHTML = "<ul> <li> C++ developer </li> </ul>"
            break;
        case 4:
            document.getElementById("soft_skills").innerHTML = "<ul> <li> Latex<br> </li> <li> Linux </li> </ul>"
            break;
    }
}

function show_education(grade)
{
    switch(grade)
    {
    case 1:
        document.getElementById("university").innerHTML = "Iran University of Science and Technology\n"
        "Location: Tehran"
        break;
    case 2:
        document.getElementById("high_school").innerHTML = "Allameh Helli (1) high school\n"
        "Location: Kerman"
        break;
    case 3:
        document.getElementById("middle_school").innerHTML = "Allameh Helli (1) middle school\n"
        "Location: Kerman"
        break;
    case 4:
        document.getElementById("elementry_school").innerHTML = "Drakhshan elemntry school\n"
        "Location: Kerman"
        break;
    }
}